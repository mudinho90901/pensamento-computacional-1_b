# PensamentoCompucional-1B
repositorio para compartilhar arquivos de pensamento computacional


eduardo augusto N8 

gabriel pereira N15

**batatinha**

Batatinha quando nasce espalha a rama pelo chão.
menininha quando dorme põe a mão no coração.
Sou pequenininha do tamanho de um botão,
carrego papai no bolso e mamãe no coração
O bolso furou e o papai caiu no chão.
Mamãe que é mais querida ficou no coração.




![batatinha quando nasce](https://i.pinimg.com/736x/bf/57/6a/bf576a8b45668b408d04c5729c528c4b--potato-kawaii.jpg)
